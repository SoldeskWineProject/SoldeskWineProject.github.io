package wine.service;

public class service {

}
