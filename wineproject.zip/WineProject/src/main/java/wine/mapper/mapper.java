package wine.mapper;

public interface mapper {

}
