package wine.validator;

public class vali {

}
