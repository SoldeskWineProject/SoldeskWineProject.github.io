package wine.interceptor;

public class Interceptor {

}
