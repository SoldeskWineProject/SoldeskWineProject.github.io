package wine.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserBean {

	private String user_id;
	private String user_pw;
	private int user_number;
	private String user_tel;
	private String user_address;
	private String user_email;
	private String user_gender;
	private String user_logindate;
	private String user_signdate;
	
}
